#!/usr/bin/env bash

[[ ! -e ./astrominer.conf ]] && echo "No config file found, exiting" && pwd && exit 1

astrominer $(< astrominer.conf) | tee --append $CUSTOM_LOG_BASENAME.log
